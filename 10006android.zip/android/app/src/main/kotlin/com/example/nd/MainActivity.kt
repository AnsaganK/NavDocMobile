package com.example.nd

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
