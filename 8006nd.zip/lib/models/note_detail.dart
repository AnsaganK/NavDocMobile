import 'dart:typed_data';

import 'package:nd/constants.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:json_annotation/json_annotation.dart';

part 'note_detail.g.dart';

@JsonSerializable()
class NoteDetail {
  final int id;
  final String title;
  final int number;
  final String text;
  final String summa;
  final bool fast;
  final String date_create;
  final String date_update;
  final String date;
  final String status;
  final Map<String, dynamic> user;
  final List<dynamic> users;
  final List<dynamic> files;

  NoteDetail(
    this.id,
    this.title,
    this.number,
    this.text,
    this.summa,
    this.fast,
    this.date_create,
    this.date_update,
    this.date,
    this.status,
    this.user,
    this.users,
    this.files,
  );
  factory NoteDetail.fromJson(Map<String, dynamic> json) =>
      _$NoteDetailFromJson(json);
  Map<String, dynamic> toJson() => _$NoteDetailToJson(this);
}

Future<NoteDetail> getNoteDetail(int id) async {
  final url = base_url + '/api/note/${id}';
  final response = await http.get(Uri.parse(url));
  if (response.statusCode == 200) {
    return NoteDetail.fromJson(json.decode(utf8.decode(response.bodyBytes)));
  } else {
    throw Exception('error: ${response.reasonPhrase}');
  }
}

Future<Uint8List> getNoteFile(int id) async {
  final url = base_url + '/notes/show/${id}';
  final response = await http.get(Uri.parse(url));
  if (response.statusCode == 200) {
    return response.bodyBytes;
  } else {
    throw Exception('error: ${response.reasonPhrase}');
  }
}
