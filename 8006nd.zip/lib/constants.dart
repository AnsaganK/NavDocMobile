import 'package:flutter/material.dart';

//final base_url = 'http://192.168.43.186:8000';
final base_url = 'http://192.168.100.55:8000';
//final base_url = 'http://185.237.165.243:8000';
//final base_url = 'http://10.0.2.2:8000';
final baseColor = Color(0xFF6dacd6);
final siteColor = Color(0xFF58A5FF);
final secondColor = Colors.orangeAccent;
final appBarColor = Color(0xFF6dacd6);

final successColor = Color(0xFF25AE88);
final editColor = Color(0xFFFFBC58);
final errorColor = Color(0xFFD75A4A);
