import 'package:flutter/material.dart';
import 'package:nd/constants.dart';
import 'package:nd/main.dart';
import 'package:nd/models/Notes.dart';
import 'package:nd/pages/NoteCreatePage.dart';
import 'package:nd/widgets/NoteCardWidget.dart';
import 'package:nd/widgets/CategoryTitle.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

class NotesNewPage extends StatefulWidget {
  @override
  _NotesNewPageState createState() => _NotesNewPageState();
}

class _NotesNewPageState extends State<NotesNewPage> {
  final GlobalKey<RefreshIndicatorState> _refreshIndicatorKey =
      new GlobalKey<RefreshIndicatorState>();
  var _currentPage = 0;
  List notes_list;
  var _pages = [
    Text("First page"),
    Text("Second Page"),
  ];
  int selectedIndex = 0;
  List categories = [
    'Все',
    'Принятые',
    'Срочные',
    'Одобренные',
    'Редактирование',
    'Отказано'
  ];
  List statuses = [
    'all',
    'my',
    'fast',
    'success',
    'edit',
    'error',
  ];

  Future<Null> _refresh;

  Future<NotesList> sendNotesList;
  Future<NotesList> myNotesList;
  @override
  void initState() {
    super.initState();
    sendNotesList = getSendNotesList();
    myNotesList = getMyNotesList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text("Мои СЗ"),
        centerTitle: true,
        backgroundColor: Color(0xFF6dacd6),
        actions: [IconButton(icon: Icon(Icons.person), onPressed: () {})],
      ),
      body: Stack(children: [
        Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage("assets/img/back.jpg"),
              fit: BoxFit.cover,
            ),
          ),
        ),
        Container(
          width: double.infinity,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Container(
                margin: EdgeInsets.symmetric(vertical: 30 / 2),
                height: 44,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: categories.length,
                  itemBuilder: (context, index) => GestureDetector(
                    onTap: () {
                      setState(() {
                        selectedIndex = index;
                      });
                    },
                    child: Container(
                      alignment: Alignment.center,
                      margin: EdgeInsets.only(
                        left: 10,
                        right: index == categories.length - 1 ? 10 : 0,
                      ),
                      padding:
                          EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                      decoration: BoxDecoration(
                          color: index == selectedIndex
                              ? secondColor
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(50),
                          border: Border.all(width: 1, color: secondColor)),
                      child: Text(
                        categories[index],
                        style: TextStyle(
                          color: index == selectedIndex
                              ? Colors.white
                              : Colors.black54,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              FutureBuilder(
                future: Future.wait(
                  [
                    myNotesList, // Future<bool> secondFuture() async {...}
                    sendNotesList, // Future<bool> firstFuture() async {...}
                  ],
                ),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    var data = snapshot.data[_currentPage].notes;
                    if (statuses[selectedIndex] == 'fast') {
                      notes_list = data
                          .where((obj) => obj.fast == true)
                          .where((obj) => obj.status == null)
                          .toList();
                    } else if (statuses[selectedIndex] == 'my') {
                      notes_list =
                          data.where((obj) => obj.status == null).toList();
                    } else if (statuses[selectedIndex] == 'success') {
                      notes_list =
                          data.where((obj) => obj.status == 'success').toList();
                    } else if (statuses[selectedIndex] == 'edit') {
                      notes_list =
                          data.where((obj) => obj.status == 'edit').toList();
                    } else if (statuses[selectedIndex] == 'error') {
                      notes_list =
                          data.where((obj) => obj.status == 'error').toList();
                    } else {
                      notes_list = snapshot.data[_currentPage].notes;
                    }
                    if (snapshot.data[_currentPage].notes.length == 0) {
                      return Center(
                        child: Container(
                          margin: EdgeInsets.only(top: 40),
                          padding: EdgeInsets.all(10),
                          child: Column(
                            children: [
                              Text(
                                "404",
                                style:
                                    TextStyle(color: secondColor, fontSize: 32),
                              ),
                              Text(
                                "Ничего не найдено",
                                style: TextStyle(color: Colors.grey),
                              ),
                            ],
                          ),
                        ),
                      );
                    } else {
                      return Expanded(
                        child: RefreshIndicator(
                          key: _refreshIndicatorKey,
                          onRefresh: () {
                            Navigator.pop(context);
                            Navigator.pushNamed(context, '/notes_page');
                          },
                          child: ListView.builder(
                            itemCount: notes_list.length,
                            itemBuilder: (context, index) {
                              return NoteCardWidget(
                                notes_list[index].id,
                                notes_list[index].number,
                                "${notes_list[index].title}",
                                "${notes_list[index].date}",
                                '${notes_list[index].user["last_name"]} ${notes_list[index].user["first_name"]}',
                                notes_list[index].fast,
                                notes_list[index].status,
                                _currentPage,
                              );
                            },
                          ),
                        ),
                      );
                    }
                  } else if (snapshot.hasError) {
                    return Center(
                      child: Text("Error"),
                    );
                  }
                  return Center(
                    child: SpinKitDualRing(
                      color: secondColor,
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ]),
      floatingActionButton: _currentPage == 1
          ? FloatingActionButton(
              onPressed: () {
                Navigator.push(context, ScaleTransition1(NoteCreatePage()));
              },
              child: Icon(Icons.add),
            )
          : null,
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.mail),
            title: Text("Принятые"),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.send),
            title: Text("Отправленные"),
          ),
        ],
        currentIndex: _currentPage,
        fixedColor: secondColor,
        onTap: (int index) {
          setState(
            () {
              print(index);
              _currentPage = index;
            },
          );
        },
      ),
    );
  }
}
