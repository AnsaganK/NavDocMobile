import 'package:flutter/material.dart';
import 'package:nd/pages/NotesListPage.dart';
import 'package:nd/constants.dart';
import 'package:nd/models/Notes.dart';
import 'package:nd/pages/NoteCreatePage.dart';
import 'package:nd/pages/NoteDetailPage.dart';
import 'package:nd/pages/NotesListPage.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Navistar Documents',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MyHomePage(title: 'Navistar Documents'),
      debugShowCheckedModeBanner: false,
      onGenerateRoute: (settings) {
        switch (settings.arguments) {
          case '/notes':
            return MaterialPageRoute(builder: (context) => NoteDetailPage());
          case '/note_detail':
            var data = settings.arguments;
            return MaterialPageRoute(
                builder: (context) => NoteDetailPage(
                      id: data,
                    ));
        }
      },
      routes: <String, WidgetBuilder>{
        "/second": (BuildContext context) => NoteDetailPage(),
        "/third": (BuildContext context) => MyHomePage(),
        "/notes_page": (BuildContext context) => NotesNewPage(),
        "/note_create": (BuildContext context) => NoteCreatePage(),
      },
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);
  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

  @override
  void initState() {
    super.initState();
  }

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Stack(children: [
      Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/img/back.jpg"),
            fit: BoxFit.cover,
          ),
        ),
      ),
      ListView(
        children: [
          SizedBox(
            height: 150,
          ),
          TextField(
            decoration: InputDecoration(labelText: "Логин"),
          ),
          SizedBox(
            height: 20,
          ),
          TextField(
            decoration: InputDecoration(labelText: "Пароль"),
          ),
          SizedBox(
            height: 20,
          ),
          Container(
            width: 120,
            height: 40,
            child: RaisedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/notes_page');
              },
              color: baseColor,
              child: Text(
                "Войти",
                style: TextStyle(color: Colors.white),
              ),
            ),
          )
        ],
      ),
    ]));
  }
}

class ScaleTransition1 extends PageRouteBuilder {
  final Widget page;
  ScaleTransition1(this.page)
      : super(
          pageBuilder: (context, animation, anotherAnimation) => page,
          transitionDuration: Duration(milliseconds: 700),
          reverseTransitionDuration: Duration(milliseconds: 200),
          transitionsBuilder: (context, animation, anotherAnimation, child) {
            animation = CurvedAnimation(
                curve: Curves.fastLinearToSlowEaseIn,
                parent: animation,
                reverseCurve: Curves.fastOutSlowIn);
            return ScaleTransition(
              alignment: Alignment.bottomRight,
              scale: animation,
              child: child,
            );
          },
        );
}

Future<http.Response> getData() async {
  final url = base_url + '/api/send_notes/1';
  print(url);
  return await http.get(Uri.parse(url));
}

loadData() {
  getData().then((response) {
    if (response.statusCode == 200) {
      print(response.body);
    } else {
      print(response.statusCode);
    }
  }).catchError((error) {
    debugPrint(error.toString());
  });
}
