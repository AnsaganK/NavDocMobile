import 'dart:io';

import 'package:advance_pdf_viewer/advance_pdf_viewer.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:nd/constants.dart';
import 'package:nd/models/note_detail.dart';
import 'package:bottom_navy_bar/bottom_navy_bar.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

class NoteDetailPage extends StatefulWidget {
  final int id;
  final String title;
  final int isMy;
  final int currentUserId = 1;
  NoteDetailPage({this.id, this.title, this.isMy});

  @override
  _NoteDetailPageState createState() => _NoteDetailPageState();
}

class _NoteDetailPageState extends State<NoteDetailPage> {
  int note_number;
  String note_title;
  final GlobalKey<RefreshIndicatorState> _refreshIndicatorKey =
      new GlobalKey<RefreshIndicatorState>();
  Future<NoteDetail> note;
  PDFDocument doc;
  bool _isLoading = true;
  final List<Tab> tabs = <Tab>[
    Tab(
      icon: Icon(Icons.info),
      text: "Информация",
    ),
    Tab(
      icon: Icon(Icons.picture_as_pdf),
      text: "PDF",
    )
  ];
  var _currentPage = 0;
  var status_name = [
    Container(
      alignment: Alignment.center,
      child: Card(
          shadowColor: Colors.white.withOpacity(0),
          color: successColor.withOpacity(.8),
          child: Container(
            width: 150,
            height: 40,
            alignment: Alignment.center,
            child: Text(
              "Подписать",
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white),
            ),
          )),
    ),
    Container(
      alignment: Alignment.center,
      child: Card(
          shadowColor: Colors.white.withOpacity(0),
          color: editColor.withOpacity(.8),
          child: Container(
            width: 150,
            height: 40,
            alignment: Alignment.center,
            child: Text(
              "На редактирование",
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white),
            ),
          )),
    ),
    Container(
      alignment: Alignment.center,
      child: Card(
          shadowColor: Colors.white.withOpacity(0),
          color: errorColor.withOpacity(.8),
          child: Container(
            width: 150,
            height: 40,
            alignment: Alignment.center,
            child: Text(
              "Отказать",
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white),
            ),
          )),
    ),
  ];
  TextEditingController textController = TextEditingController();
  @override
  void initState() {
    super.initState();
    data();
    loadDocument();
  }

  loadDocument() async {
    doc = await PDFDocument.fromURL(
      '${base_url}/notes/show/${widget.id}',
      cacheManager: CacheManager(
        Config(
          "customCacheKey",
          stalePeriod: const Duration(days: 1),
          maxNrOfCacheObjects: 10,
        ),
      ),
    );
    setState(() => _isLoading = false);
  }

  data() async {
    note = getNoteDetail(widget.id);
    note.then((value) {
      note_number = value.number;
      note_title = value.title;
    });
  }

//PDFDocument doc = await PDFDocument.fromURL('http://www.africau.edu/images/default/sample.pdf');
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: baseColor,
          title: Text(widget.title),
          centerTitle: true,
          bottom: TabBar(
            tabs: tabs,
          ),
          actions: [
            widget.isMy == 0
                ? IconButton(
                    icon: SvgPicture.asset("assets/img/checked.svg"),
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (BuildContext context) => Dialog(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(40)),
                          elevation: 20,
                          child: Container(
                            padding: EdgeInsets.all(10),
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(20)),
                            alignment: Alignment.center,
                            width: 300,
                            height: 300,
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                children: [
                                  Text(
                                    "Подтвердите действие",
                                    style: TextStyle(
                                        fontSize: 19, color: Colors.grey),
                                  ),
                                  Divider(),
                                  Text(
                                    "СЗ №${note_number}",
                                    style: TextStyle(
                                        fontSize: 18, color: Colors.black54),
                                  ),
                                  Text(
                                    "${note_title}",
                                    style: TextStyle(
                                        fontSize: 14, color: Colors.black38),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  status_name[_currentPage],
                                  SizedBox(
                                    height: 10,
                                  ),
                                  SizedBox(
                                    height: 60,
                                    child: textController.text != ""
                                        ? Text(
                                            textController.text,
                                            style: TextStyle(),
                                            maxLines: 4,
                                            overflow: TextOverflow.ellipsis,
                                          )
                                        : Text(
                                            "Без комментариев",
                                            style: TextStyle(
                                              color: Colors.grey,
                                            ),
                                            maxLines: 3,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      RaisedButton(
                                        color: baseColor,
                                        onPressed: () {},
                                        child: Text(
                                          "Подтвердить",
                                          style: TextStyle(color: Colors.white),
                                        ),
                                      ),
                                    ],
                                  )
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    })
                : IconButton(icon: Icon(Icons.more_vert), onPressed: () {})
          ],
        ),
        body: TabBarView(
          children: [
            Stack(
              children: [
                Container(
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage("assets/img/back.jpg"),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                RefreshIndicator(
                  key: _refreshIndicatorKey,
                  onRefresh: () {
                    /*
                    Navigator.pop(context);
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (BuildContext context) => NoteDetailPage(
                            id: widget.id,
                            title: widget.title,
                            isMy: widget.isMy,
                          ),
                        ));*/
                  },
                  child: ListView(
                    children: [
                      FutureBuilder(
                        future: note,
                        builder: (context, snapshot) {
                          if (snapshot.hasData) {
                            print(snapshot.data);
                            if (snapshot.data == null) {
                              return Center(
                                child: Container(
                                  margin: EdgeInsets.only(top: 40),
                                  padding: EdgeInsets.all(10),
                                  child: Column(
                                    children: [
                                      Text(
                                        "404",
                                        style: TextStyle(
                                            color: secondColor, fontSize: 32),
                                      ),
                                      Text(
                                        "Ничего не найдено",
                                        style: TextStyle(color: Colors.grey),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            } else {
                              return Container(
                                alignment: Alignment.center,
                                padding: EdgeInsets.all(8),
                                margin: EdgeInsets.only(top: 5),
                                child: Column(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    /*Padding(
                                      padding:
                                          const EdgeInsets.only(bottom: 10.0),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceAround,
                                        children: [
                                          RaisedButton(
                                            elevation: 3,
                                            onPressed: () async {
                                              PDFDocument doc =
                                                  await PDFDocument.fromURL(
                                                      'http://www.africau.edu/images/default/sample.pdf');
                                            },
                                            color: secondColor,
                                            child: Container(
                                              decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          20)),
                                              child: Text(
                                                "PDF",
                                                style: TextStyle(
                                                    color: Colors.white),
                                              ),
                                            ),
                                          ),
                                          RaisedButton(
                                            elevation: 3,
                                            onPressed: () {},
                                            color: secondColor,
                                            child: Text("PDF(Без подписи)",
                                                style: TextStyle(
                                                    color: Colors.white)),
                                          ),
                                        ],
                                      ),
                                    ),*/
                                    Container(
                                      padding: EdgeInsets.all(28),
                                      decoration: BoxDecoration(
                                          color: Colors.white,
                                          boxShadow: [
                                            BoxShadow(
                                                color: Colors.grey[300],
                                                blurRadius: 1,
                                                spreadRadius: 1),
                                          ],
                                          border: Border.all(
                                              width: 1, color: Colors.black12),
                                          borderRadius:
                                              BorderRadius.circular(10)),
                                      child: Column(
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                bottom: 18.0),
                                            child: Text(
                                              "Служебная записка №${snapshot.data.number}",
                                              style: TextStyle(
                                                  color: Colors.black54),
                                            ),
                                          ),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text(
                                                "Создал",
                                                style: TextStyle(
                                                    color: Colors.black54),
                                              ),
                                              Text(
                                                  "${snapshot.data.user['first_name']} ${snapshot.data.user['last_name']}")
                                            ],
                                          ),
                                          SizedBox(height: 5),
                                          Divider(),
                                          SizedBox(height: 5),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text(
                                                "Название",
                                                style: TextStyle(
                                                    color: Colors.black54),
                                              ),
                                              Text("${snapshot.data.title}")
                                            ],
                                          ),
                                          SizedBox(height: 5),
                                          Divider(),
                                          SizedBox(height: 5),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text(
                                                "Дата",
                                                style: TextStyle(
                                                    color: Colors.black54),
                                              ),
                                              Text("${snapshot.data.date}"),
                                            ],
                                          ),
                                          SizedBox(height: 5),
                                          Divider(),
                                          SizedBox(height: 5),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text(
                                                "Дата создания",
                                                style: TextStyle(
                                                    color: Colors.black54),
                                              ),
                                              Text(
                                                  "${snapshot.data.date_create.split('T')[0]}"),
                                            ],
                                          ),
                                          SizedBox(height: 5),
                                          Divider(),
                                          SizedBox(height: 5),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text(
                                                "Текст",
                                                style: TextStyle(
                                                    color: Colors.black54),
                                              ),
                                              Container(
                                                width: 200,
                                                child: Text(
                                                  "${snapshot.data.text}",
                                                  textAlign: TextAlign.right,
                                                  style: TextStyle(),
                                                ),
                                              ),
                                            ],
                                          ),
                                          SizedBox(height: 5),
                                          Divider(),
                                          SizedBox(height: 5),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text(
                                                "Итого",
                                                style: TextStyle(
                                                    color: Colors.black54),
                                              ),
                                              Container(
                                                width: 200,
                                                child: Text(
                                                  "${snapshot.data.summa}",
                                                  textAlign: TextAlign.right,
                                                  style: TextStyle(),
                                                ),
                                              ),
                                            ],
                                          ),
                                          SizedBox(height: 5),
                                          Divider(),
                                          SizedBox(height: 5),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text(
                                                "Файлы",
                                                style: TextStyle(
                                                    color: Colors.black54),
                                              ),
                                              Container(
                                                width: 200,
                                                child: Text(
                                                  "${snapshot.data.summa}",
                                                  textAlign: TextAlign.right,
                                                  style: TextStyle(),
                                                ),
                                              ),
                                            ],
                                          ),
                                          SizedBox(height: 5),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      height: 15,
                                    ),
                                    widget.isMy == 0
                                        ? Column(
                                            children: [
                                              Container(
                                                  margin: const EdgeInsets.only(
                                                      bottom: 20.0),
                                                  child:
                                                      null //status_name[_currentPage],
                                                  ),
                                              TextField(
                                                controller: textController,
                                                decoration: InputDecoration(
                                                  fillColor: Colors.white,
                                                  labelText: "Комментарии",
                                                  focusedBorder:
                                                      OutlineInputBorder(
                                                    borderSide: BorderSide(
                                                        color: secondColor,
                                                        width: 1.0),
                                                  ),
                                                  enabledBorder:
                                                      OutlineInputBorder(
                                                    borderSide: BorderSide(
                                                        color: baseColor,
                                                        width: 1.0),
                                                  ),
                                                ),
                                                minLines: 2,
                                                maxLines: 10,
                                              )
                                            ],
                                          )
                                        : Column(
                                            children: List.generate(
                                                snapshot.data.users.length,
                                                (index) {
                                              return Card(
                                                child: ListTile(
                                                  leading: snapshot.data
                                                                  .users[index]
                                                              ['status'] ==
                                                          'success'
                                                      ? Icon(
                                                          Icons.check,
                                                          color: successColor,
                                                        )
                                                      : snapshot.data.users[index]
                                                                  ['status'] ==
                                                              'edit'
                                                          ? Icon(
                                                              Icons
                                                                  .warning_amber_outlined,
                                                              color: editColor,
                                                            )
                                                          : snapshot.data.users[
                                                                          index]
                                                                      [
                                                                      'status'] ==
                                                                  'error'
                                                              ? Icon(
                                                                  Icons.close,
                                                                  color:
                                                                      errorColor,
                                                                )
                                                              : snapshot.data.users[
                                                                              index]
                                                                          ['status'] ==
                                                                      null
                                                                  ? Icon(
                                                                      Icons
                                                                          .timer,
                                                                      color: Colors
                                                                          .grey,
                                                                    )
                                                                  : null,
                                                  title: Text(
                                                      "${snapshot.data.users[index]['user']['first_name']} ${snapshot.data.users[index]['user']['last_name']}"
                                                      "\n${snapshot.data.users[index]['date_create'] != null && snapshot.data.users[index]['status'] != null ? snapshot.data.users[index]['date_create'].toString().substring(0, 10) + '    ' + snapshot.data.users[index]['date_create'].toString().substring(11, 19) : ''}"),
                                                  //Text(
                                                  subtitle: Text(
                                                      "${snapshot.data.users[index]['status'] == null ? '' : '\n' + snapshot.data.users[index]['comment']}"),
                                                ),
                                              );
                                            }),
                                          ),
                                  ],
                                ),
                              );
                            }
                          }
                          return Container(
                            alignment: Alignment.center,
                            margin: EdgeInsets.only(top: 130),
                            child: SpinKitDualRing(
                              color: secondColor,
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Container(
              child: _isLoading
                  ? Center(child: CircularProgressIndicator())
                  : PDFViewer(
                      document: doc,
                      //uncomment below line to preload all pages
                      //lazyLoad: false,
                      // uncomment below line to scroll vertically
                      // scrollDirection: Axis.vertical,

                      //uncomment below code to replace bottom navigation with your own
                      /* navigationBuilder:
                      (context, page, totalPages, jumpToPage, animateToPage) {
                    return ButtonBar(
                      alignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget>[
                        IconButton(
                          icon: Icon(Icons.first_page),
                          onPressed: () {
                            jumpToPage()(page: 0);
                          },
                        ),
                        IconButton(
                          icon: Icon(Icons.arrow_back),
                          onPressed: () {
                            animateToPage(page: page - 2);
                          },
                        ),
                        IconButton(
                          icon: Icon(Icons.arrow_forward),
                          onPressed: () {
                            animateToPage(page: page);
                          },
                        ),
                        IconButton(
                          icon: Icon(Icons.last_page),
                          onPressed: () {
                            jumpToPage(page: totalPages - 1);
                          },
                        ),
                      ],
                    );
                  }, */
                    ),
            )
          ],
        ),
        bottomNavigationBar: widget.isMy == 0
            ? BottomNavyBar(
                selectedIndex: _currentPage,
                showElevation: true,
                containerHeight: 80,
                itemCornerRadius: 8,
                curve: Curves.easeIn,
                mainAxisAlignment: MainAxisAlignment.center,
                onItemSelected: (index) => setState(() {
                  _currentPage = index;
                }),
                items: [
                  BottomNavyBarItem(
                      inactiveColor: Colors.grey,
                      icon: Icon(Icons.check),
                      textAlign: TextAlign.center,
                      title: Text("Подписать"),
                      activeColor: successColor),
                  BottomNavyBarItem(
                      inactiveColor: Colors.grey,
                      icon: Icon(Icons.warning_amber_outlined),
                      title: Text("Возврат"),
                      textAlign: TextAlign.center,
                      activeColor: editColor),
                  BottomNavyBarItem(
                      inactiveColor: Colors.grey,
                      icon: Icon(Icons.close),
                      title: Text("Отказать"),
                      textAlign: TextAlign.center,
                      activeColor: errorColor),
                ],
              )
            : null,
      ),
    );
  }
}
