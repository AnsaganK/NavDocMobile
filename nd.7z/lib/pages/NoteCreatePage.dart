import 'package:flutter/material.dart';

class NoteCreatePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(
            Icons.arrow_back,
            color: Colors.black54,
          ),
        ),
        title: Text(
          "Создание СЗ",
          style: TextStyle(color: Colors.black54),
        ),
        centerTitle: true,
      ),
    );
  }
}
