import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:nd/constants.dart';
import 'package:nd/models/note_detail.dart';
import 'package:bottom_navy_bar/bottom_navy_bar.dart';

class NoteDetailPage extends StatefulWidget {
  final int id;
  final String title;
  final int isMy;
  NoteDetailPage({this.id, this.title, this.isMy});
  @override
  _NoteDetailPageState createState() => _NoteDetailPageState();
}

class _NoteDetailPageState extends State<NoteDetailPage> {
  Future<NoteDetail> note;
  var _currentPage = 0;
  var status_name = [
    Container(
      alignment: Alignment.center,
      child: Card(
          shadowColor: Colors.white.withOpacity(0),
          color: successColor.withOpacity(.5),
          child: Container(
            width: 150,
            height: 40,
            alignment: Alignment.center,
            child: Text(
              "Подписать",
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white),
            ),
          )),
    ),
    Container(
      alignment: Alignment.center,
      child: Card(
          shadowColor: Colors.white.withOpacity(0),
          color: editColor.withOpacity(.5),
          child: Container(
            width: 150,
            height: 40,
            alignment: Alignment.center,
            child: Text(
              "На редактирование",
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white),
            ),
          )),
    ),
    Container(
      alignment: Alignment.center,
      child: Card(
          shadowColor: Colors.white.withOpacity(0),
          color: errorColor.withOpacity(.5),
          child: Container(
            width: 150,
            height: 40,
            alignment: Alignment.center,
            child: Text(
              "Отказать",
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white),
            ),
          )),
    ),
  ];
  @override
  void initState() {
    super.initState();
    note = getNoteDetail(widget.id);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: baseColor,
        title: Text(widget.title),
        centerTitle: true,
        actions: [
          IconButton(
              icon: SvgPicture.asset("assets/img/checked.svg"),
              onPressed: () {})
        ],
      ),
      body: Stack(children: [
        Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage("assets/img/back.jpg"),
              fit: BoxFit.cover,
            ),
          ),
        ),
        ListView(
          children: [
            FutureBuilder(
              future: note,
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  print(snapshot.data);
                  if (snapshot.data == null) {
                    return Center(
                      child: Container(
                        margin: EdgeInsets.only(top: 40),
                        padding: EdgeInsets.all(10),
                        child: Column(
                          children: [
                            Text(
                              "404",
                              style:
                                  TextStyle(color: secondColor, fontSize: 32),
                            ),
                            Text(
                              "Ничего не найдено",
                              style: TextStyle(color: Colors.grey),
                            ),
                          ],
                        ),
                      ),
                    );
                  } else {
                    return Container(
                      alignment: Alignment.center,
                      padding: EdgeInsets.all(8),
                      margin: EdgeInsets.only(top: 10),
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              RaisedButton(
                                elevation: 3,
                                onPressed: () {},
                                color: secondColor,
                                child: Container(
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(20)),
                                  child: Text(
                                    "PDF",
                                    style: TextStyle(color: Colors.white),
                                  ),
                                ),
                              ),
                              RaisedButton(
                                elevation: 3,
                                onPressed: () {},
                                color: secondColor,
                                child: Text("PDF(Без подписи)",
                                    style: TextStyle(color: Colors.white)),
                              ),
                            ],
                          ),
                          Container(
                            padding: EdgeInsets.all(28),
                            decoration: BoxDecoration(
                                color: Colors.white,
                                boxShadow: [
                                  BoxShadow(
                                      color: Colors.grey[100],
                                      blurRadius: 1,
                                      spreadRadius: 1),
                                ],
                                border:
                                    Border.all(width: 1, color: Colors.black12),
                                borderRadius: BorderRadius.circular(10)),
                            child: Column(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(bottom: 18.0),
                                  child: Text(
                                    "Служебная записка №${snapshot.data.number}",
                                    style: TextStyle(color: Colors.black54),
                                  ),
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      "Создал",
                                      style: TextStyle(color: Colors.black54),
                                    ),
                                    Text(
                                        "${snapshot.data.user['first_name']} ${snapshot.data.user['last_name']}")
                                  ],
                                ),
                                SizedBox(height: 5),
                                Divider(),
                                SizedBox(height: 5),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      "Название",
                                      style: TextStyle(color: Colors.black54),
                                    ),
                                    Text("${snapshot.data.title}")
                                  ],
                                ),
                                SizedBox(height: 5),
                                Divider(),
                                SizedBox(height: 5),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      "Дата",
                                      style: TextStyle(color: Colors.black54),
                                    ),
                                    Text("${snapshot.data.date}"),
                                  ],
                                ),
                                SizedBox(height: 5),
                                Divider(),
                                SizedBox(height: 5),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      "Дата создания",
                                      style: TextStyle(color: Colors.black54),
                                    ),
                                    Text(
                                        "${snapshot.data.date_create.split('T')[0]}"),
                                  ],
                                ),
                                SizedBox(height: 5),
                                Divider(),
                                SizedBox(height: 5),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      "Текст",
                                      style: TextStyle(color: Colors.black54),
                                    ),
                                    Container(
                                      width: 200,
                                      child: Text(
                                        "${snapshot.data.text}",
                                        textAlign: TextAlign.right,
                                        style: TextStyle(),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 5),
                                Divider(),
                                SizedBox(height: 5),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      "Итого",
                                      style: TextStyle(color: Colors.black54),
                                    ),
                                    Container(
                                      width: 200,
                                      child: Text(
                                        "${snapshot.data.summa}",
                                        textAlign: TextAlign.right,
                                        style: TextStyle(),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 5),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 15,
                          ),
                          widget.isMy == 0
                              ? Column(
                                  children: [
                                    Container(
                                      margin:
                                          const EdgeInsets.only(bottom: 20.0),
                                      child: status_name[_currentPage],
                                    ),
                                    TextField(
                                      decoration: InputDecoration(
                                        labelText: "Комментарии",
                                        focusedBorder: OutlineInputBorder(
                                          borderSide: BorderSide(
                                              color: secondColor, width: 2.0),
                                        ),
                                        enabledBorder: OutlineInputBorder(
                                          borderSide: BorderSide(
                                              color: Colors.black12,
                                              width: 2.0),
                                        ),
                                      ),
                                      minLines: 2,
                                      maxLines: 10,
                                    )
                                  ],
                                )
                              : Column(
                                  children: List.generate(
                                      snapshot.data.users.length, (index) {
                                    return Card(
                                      child: ListTile(
                                        leading: snapshot.data.users[index]
                                                    ['status'] ==
                                                'success'
                                            ? Icon(
                                                Icons.edit,
                                                color: successColor,
                                              )
                                            : snapshot.data.users[index]
                                                        ['status'] ==
                                                    'edit'
                                                ? Icon(
                                                    Icons.warning,
                                                    color: editColor,
                                                  )
                                                : snapshot.data.users[index]
                                                            ['status'] ==
                                                        'error'
                                                    ? Icon(
                                                        Icons.dangerous,
                                                        color: errorColor,
                                                      )
                                                    : snapshot.data.users[index]
                                                                ['status'] ==
                                                            null
                                                        ? Icon(
                                                            Icons.timer,
                                                            color: Colors.grey,
                                                          )
                                                        : null,
                                        title: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text(
                                                  "${snapshot.data.users[index]['user']['first_name']} ${snapshot.data.users[index]['user']['last_name']}"),
                                              //Text(
                                              //    "${snapshot.data.users[index]['date_create']}"),
                                            ]),
                                        subtitle: Text(
                                            "${snapshot.data.users[index]['status'] == null ? '' : snapshot.data.users[index]['comment']}"),
                                      ),
                                    );
                                  }),
                                ),
                        ],
                      ),
                    );
                  }
                }
                return Container(
                  alignment: Alignment.center,
                  margin: EdgeInsets.only(top: 130),
                  child: SpinKitDualRing(
                    color: secondColor,
                  ),
                );
              },
            ),
          ],
        ),
      ]),
      bottomNavigationBar: widget.isMy == 0
          ? BottomNavyBar(
              selectedIndex: _currentPage,
              showElevation: true,
              itemCornerRadius: 8,
              curve: Curves.easeIn,
              mainAxisAlignment: MainAxisAlignment.center,
              onItemSelected: (index) => setState(() {
                _currentPage = index;
              }),
              items: [
                BottomNavyBarItem(
                    inactiveColor: Colors.grey,
                    icon: Icon(Icons.edit),
                    textAlign: TextAlign.center,
                    title: Text("Подписать"),
                    activeColor: successColor),
                BottomNavyBarItem(
                    inactiveColor: Colors.grey,
                    icon: Icon(Icons.warning),
                    title: Text("Возврат"),
                    textAlign: TextAlign.center,
                    activeColor: editColor),
                BottomNavyBarItem(
                    inactiveColor: Colors.grey,
                    icon: Icon(Icons.error),
                    title: Text("Отказать"),
                    textAlign: TextAlign.center,
                    activeColor: errorColor),
              ],
            )
          : null,
    );
  }
}
